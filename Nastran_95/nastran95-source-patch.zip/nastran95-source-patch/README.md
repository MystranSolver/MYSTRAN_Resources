# NASTRAN-95 source patch

This directory contains the fix needed to build and run NASTRAN-95 with a
modern gfortran (13.x) toolchain, both natively on Linux and cross-compiled
for Windows via MinGW-w64.

## Files

- `nastran95-fixes.patch` — a `git diff`-format patch. Apply it against a
  clone of `AeroDME/NASTRAN-95` (or `nasa/NASTRAN-95` plus that fork's
  `makefile`/`sbin/nastran.py`) with:
  ```
  cd NASTRAN-95
  git apply /path/to/nastran95-fixes.patch
  ```
- `xdcode.f`, `makefile`, `nastran.py` — the three full patched files, in
  case `git apply` doesn't cleanly match your checkout (e.g. if the
  upstream fork has moved on since this was made).

## What's patched and why

1. **`makefile`** — adds `-fallow-invalid-boz` to the compiler flags.
   Modern gfortran rejects the old-style `'FF'X` postfix hex-literal
   syntax used throughout this 1970s/80s codebase unless told to allow it.

2. **`mis/xdcode.f`** — the real fix. This is a NASA/RPK-Corporation
   subroutine (1983) that unpacks a card image from a 4-characters-per-word
   array (`RECORD`) into a 1-character-per-word array (`ICHAR`), so the
   DMAP-rigid-format parser can scan it character by character. The
   original implementation did this via an internal `WRITE`/`READ`
   round-trip using Fortran `A4`/`A1` format editing. Under gfortran,
   reading a **comma** character with an `A1` edit descriptor into a
   non-`CHARACTER` (`INTEGER`) variable silently produces a blank instead
   of the comma. Since commas delimit the number list on `****SBST`
   control cards (e.g. `****SBST   1,  3`, which mark which DMAP
   statements belong to which numbered "subset" of a solution sequence),
   this corrupted the parser's view of every rigid format and caused
   `USER FATAL MESSAGE 8020, SYNTAX ERROR` on essentially every real
   analysis job. This is the same crash reported, unresolved, in
   [nasa/NASTRAN-95 issue #15](https://github.com/nasa/NASTRAN-95/issues/15).
   The fix replaces the WRITE/READ round-trip with an explicit byte copy
   using the codebase's own `KHRFN1` utility function, which works on
   character storage directly and doesn't go through formatted I/O, so
   it isn't subject to the gfortran quirk.

3. **`sbin/nastran.py`** — two small fixes to the Python job-launcher
   script: (a) `0755` → `0o755` (the old-style octal literal is valid
   Python 2 but a syntax error in Python 3), and (b) the hardcoded
   `bin/nastran.x` executable path is now OS-aware, resolving to
   `bin/nastran.exe` when running on Windows (`os.name == 'nt'`) and
   `bin/nastran.x` on Linux/Unix.

## How the bug was found

Full narrative is in `NASTRAN-95-Build-Report.md` at the top level of this
delivery. Short version: added targeted `WRITE` debug statements to trace
the exact byte values flowing through the DMAP compiler's card-image
buffer at the point of failure, found the comma consistently going
missing, wrote an isolated standalone Fortran test program to reproduce
just the `A1`-into-`INTEGER` read in a few lines, confirmed it was a
compiler/runtime quirk (not a logic bug in the 1983 code), and located
the one subroutine (`XDCODE`) responsible.

## Rebuilding from source

```bash
git clone https://github.com/AeroDME/NASTRAN-95.git
cd NASTRAN-95
git apply /path/to/nastran95-fixes.patch

# Linux build
sudo apt install gfortran
make nastran nasthelp nastplot chkfil ff

# Windows cross-build (produces PE32+ .exe files, from Linux or WSL)
sudo apt install gfortran-mingw-w64-x86-64
make F77=x86_64-w64-mingw32-gfortran AR=x86_64-w64-mingw32-ar \
     nastran nasthelp nastplot chkfil ff
```

Note: a plain parallel `make -jN` can race on `lib/libnas.a` (the makefile
doesn't declare it as a dependency of `bin/nastran.x`, only of the
`nastran` phony target). If you build in parallel and hit `cannot find
-lnas`, just re-run `make lib/libnas.a` followed by `make bin/nastran.x`
serially.
