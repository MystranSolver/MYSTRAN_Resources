# NASTRAN-95 — Windows x86-64 build

This is a working build of NASA's COSMIC NASTRAN-95 (from the community
fork of `nasa/NASTRAN-95` maintained at `AeroDME/NASTRAN-95`), cross-compiled
for 64-bit Windows with MinGW-w64 gfortran, with two portability bugs fixed
(see `../nastran95-source-patch/` for details). It has been tested and
verified under Wine to reproduce NASA's own 1995 reference results
bit-for-bit on multiple demo problems. It has not yet been run on a real
Windows machine — see the note at the bottom.

## Contents

- `bin/` — the 5 compiled programs: `nastran.exe` (the solver),
  `nasthelp.exe`, `nastplot.exe`, `chkfil.exe`, `ff.exe`
- `rf/` — rigid formats (the built-in DMAP solution sequences NASTRAN needs
  at runtime — required)
- `um/` — help-text files used by `nasthelp.exe` (optional but harmless to keep)
- `inp/` — 132 sample/demo input decks from NASA, useful for testing
- `sbin/nastran.py` — a Python 3 wrapper that sets up the ~20 environment
  variables NASTRAN needs and runs a job for you (works on Windows the same
  way it does on Linux — it detects the OS and writes a `.bat` job script
  instead of a `.sh` one)

## Requirements

- Windows 10/11, 64-bit
- Python 3 (only needed for the `nastran.py` wrapper — get it from
  python.org or the Microsoft Store if you don't have it; the binaries
  themselves have no Python dependency)
- No other runtime dependencies — the executables are statically linked

## Quick start (recommended: use the wrapper)

Open a Command Prompt or PowerShell in this folder:

```bat
mkdir OUTPUT
python sbin\nastran.py -o OUTPUT inp\d01012a.inp
```

(If `python` isn't recognized, try `py` instead.)

This produces `OUTPUT\d01012a.f06` (the main results file — displacements,
stresses, etc.), plus a `.f04` log and a few other auxiliary files. Open the
`.f06` in any text editor; the numeric results are in there.

Run any of the 132 files in `inp\` the same way. Some of the sample decks
are chained (e.g. `d01011b.inp` continues from `d01011a.inp`'s restart
data) — those need extra flags (`--SOF1`, `--OPTPNM`, etc.); run
`python sbin\nastran.py --help` to see them, or just stick to the
non-restart `...a.inp` files, which is most of them.

## Running the solver directly (no Python)

`bin\nastran.exe` reads its input deck from stdin and writes the `.f06`
to stdout. It needs several environment variables set first (in `cmd.exe`):

```bat
mkdir C:\nastran_scratch
set RFDIR=C:\path\to\nastran95-windows-x64\rf
set DIRCTY=C:\nastran_scratch
set LOGNM=C:\output.f04
set DBMEM=12000000
set OCMEM=2000000
rem The rest (NPTPNM, PLTNM, DICTNM, PUNCHNM, OPTPNM, IN12, OUT11,
rem FTN11 through FTN23, SOF1, SOF2) also need to be set to a writable
rem file path, or NASTRAN will error trying to open an empty filename.
rem See sbin\nastran.py for the exact full list — it's easiest to just
rem use the wrapper.
bin\nastran.exe < inp\d01012a.inp > output.f06
```

In practice, just use `sbin\nastran.py` — it handles all of this for you.

## Verifying your setup works

```bat
python sbin\nastran.py -o OUTPUT inp\d01012a.inp
findstr /I "FATAL SEVERE" OUTPUT\d01012a.f06
rem   ^ should print nothing
```

Open `OUTPUT\d01012a.f06` and check it ends with `* * * END OF JOB * * *`.

## A note on how this was tested

This Windows build was compiled on Linux using the MinGW-w64 cross-compiler
and verified by running it under Wine (a Windows-compatibility layer),
not on a real Windows machine — I don't have one available in this
environment. The Wine test reproduced NASA's 1995 reference results
exactly, which is a strong signal, but Wine isn't a perfect stand-in for
real Windows. If you hit anything unexpected on your machine (a missing
DLL error, a crash on startup, etc.), let me know what it says and I can
help debug it — that would be the first real Windows-native test of this
build.

## Background

See `NASTRAN-95-Build-Report.md` (shipped alongside this package) for the
full story of what was built, what was broken, and how it was fixed and
verified.
