# NASTRAN-95 — Linux x86-64 build

This is a working build of NASA's COSMIC NASTRAN-95 (from the community
fork of `nasa/NASTRAN-95` maintained at `AeroDME/NASTRAN-95`), compiled
for 64-bit Linux with gfortran, with two portability bugs fixed (see
`../nastran95-source-patch/` for details). It has been verified to
reproduce NASA's own 1995 reference results bit-for-bit on multiple demo
problems.

## Contents

- `bin/` — the 5 compiled programs: `nastran.x` (the solver), `nasthelp.x`,
  `nastplot.x`, `chkfil.x`, `ff.x`
- `rf/` — rigid formats (the built-in DMAP solution sequences NASTRAN needs
  at runtime — required)
- `um/` — help-text files used by `nasthelp.x` (optional but harmless to keep)
- `inp/` — 132 sample/demo input decks from NASA, useful for testing
- `sbin/nastran.py` — a Python 3 wrapper that sets up the ~20 environment
  variables NASTRAN needs and runs a job for you

## Requirements

- Linux x86-64 (built/tested on Ubuntu 24.04; should run on most modern
  distros — the binaries are statically linked against `libnas`, only
  depending on the system's standard C/Fortran runtime libraries)
- Python 3 (only needed for the `nastran.py` wrapper — the binaries
  themselves have no Python dependency)

## Quick start (recommended: use the wrapper)

```bash
cd nastran95-linux-x64
mkdir -p OUTPUT
python3 sbin/nastran.py -o OUTPUT inp/d01012a.inp
```

This produces `OUTPUT/d01012a.f06` (the main results file — displacements,
stresses, etc.), plus a `.f04` log and a few other auxiliary files. Open the
`.f06` in any text editor; the numeric results are in there.

Run any of the 132 files in `inp/` the same way. Some of the sample decks
are chained (e.g. `d01011b.inp` continues from `d01011a.inp`'s restart
data) — those need extra flags (`--SOF1`, `--OPTPNM`, etc.); run
`python3 sbin/nastran.py --help` to see them, or just stick to the
non-restart `...a.inp` files, which is most of them.

## Running the solver directly (no Python)

If you don't want to use the wrapper, `bin/nastran.x` reads its input deck
from stdin and writes the `.f06` to stdout. It needs several environment
variables set first — at minimum:

```bash
mkdir -p /tmp/nastran_scratch
export RFDIR=/path/to/nastran95-linux-x64/rf
export DIRCTY=/tmp/nastran_scratch
export LOGNM=/tmp/output.f04
export DBMEM=12000000
export OCMEM=2000000
# The rest (NPTPNM, PLTNM, DICTNM, PUNCHNM, OPTPNM, IN12, OUT11,
# FTN11 through FTN23, SOF1, SOF2) also need to be set to a writable
# file path, or NASTRAN will error trying to open an empty filename.
# See sbin/nastran.py for the exact full list — it's easiest to just
# use the wrapper.
bin/nastran.x < inp/d01012a.inp > output.f06
```

In practice, just use `sbin/nastran.py` — it handles all of this for you.

## Verifying your setup works

```bash
python3 sbin/nastran.py -o OUTPUT inp/d01012a.inp
grep -i "FATAL\|SEVERE" OUTPUT/d01012a.f06   # should print nothing
tail -20 OUTPUT/d01012a.f06                   # should end with "* * * END OF JOB * * *"
```

If you want to compare against NASA's original 1995 reference output for
this same problem, it's `demoout/d01012a.out` in the original source tree
(not included here to keep this package small) — the numeric results
should match exactly, aside from the date stamp.

## Background

See `NASTRAN-95-Build-Report.md` (shipped alongside this package) for the
full story of what was built, what was broken, and how it was fixed and
verified.
